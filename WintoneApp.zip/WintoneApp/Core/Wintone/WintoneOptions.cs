﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WintoneApp.Core.Wintone
{
    public class WintoneOptions
    {
        public const string Key = "Wintone";

        public string UserId { get; set; }
        public string LibraryPath { get; set; }
    }
}
